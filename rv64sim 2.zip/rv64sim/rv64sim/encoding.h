#ifndef ENCODING_H
#define ENCODING_H

#include <iostream>
#include <string>
#include "processor.h"

class encoding{

    private:
        //address
        //memory
        memory* memo;
        //declare verbose
        bool verbose_;
        processor* pro;
        int *instr;
        string sets_instr();
         //get address 
        void load_address_(uint64_t memory_address);
        uint32_t signed_bit_int32(int begin,int end);
        //show 32 bit signed values
        void show_signed_bit_int32(signed int res);
        uint32_t unsigned_bit_int32(int begin,int end);
        //show 32 bit unsigned values
        void show_unsigned_bit_int32(unsigned int res);
        void misaligned_load(uint64_t error_address);
        void misaligned_store(uint64_t error_address);
        void machine_mode_interrupt();
        void machine_mode_interrupt_vectored(int causecode);
        void user_mode_interrupt(int mode);
    
    public:
        //Instruction sets
        
        //Constructor   
        encoding(memory* main_memory,processor* processor_,bool verbose);// 
       
        //excution of commands   
        void computing(uint64_t memory_address);//
        void mret(uint64_t memory_address, unsigned int Cause_code);//
        void misaligned_instr();//
        
};

#endif

