#ifndef PROCESSOR_H
#define PROCESSOR_H

#include "memory.h"

using namespace std;

class processor {

 private:

  // TODO: Add private members here
   memory* memo;
   bool verbose_;
   int *pc_;
   int **register_;
   int instr_executed;
   uint64_t breakpoint;
   int **csr_array;
   unsigned int Privilege_level;
   bool csr_defined[4096];
   bool f11_f14_read_only;

 public:

  // Consructor
   processor(memory* main_memory, bool verbose,bool stage2);
  // Display PC value
  void show_pc();
  // Set PC to new value
  void set_pc(uint64_t new_pc);
  //get the PC value for later use
  uint64_t get_pc();
  //get the Regisiter value for later use
  uint64_t get_reg(unsigned int new_reg);
  // Display register value
  void show_reg(unsigned int new_reg);
  // Set register to new value
  void set_reg(unsigned int new_reg, uint64_t new_value);
  // Execute a number of instructions
  void execute(processor* processor_, unsigned int num, bool breakpoint_check);
  // Clear breakpoint
  void clear_breakpoint();
  // Show privilege level
  void show_prv();
  // Set privilege level
  void set_prv(unsigned int prv_num);
  unsigned int return_prv();
  // Display CSR value
  void show_csr(unsigned int csr_num);
  // Set CSR to new value
  void set_csr(unsigned int csr_num, uint64_t new_value);
  uint64_t get_csr(unsigned int csr_num);
  // Set breakpoint at an address
  void set_breakpoint(uint64_t address);
  void set_instruction_count(uint64_t count);
  bool csr_is_defined(unsigned int csr_num);
  bool illegal_csr_write(unsigned int csr_num);
  uint64_t get_instruction_count();
  // Used for Postgraduate assignment. Undergraduate assignment can return 0.
  uint64_t get_cycle_count();

};

#endif
