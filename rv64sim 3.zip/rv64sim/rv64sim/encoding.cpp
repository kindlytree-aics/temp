#include <iostream>
#include <fstream>
#include <iomanip>
#include <stdlib.h>
#include <cstdio>
#include <string>
#include <cmath>

#include "encoding.h" 
#include "memory.h"
#include "processor.h"


using namespace std;

encoding::encoding(memory* main_memory,processor* processor_,bool verbose) {
    memo = main_memory;
    verbose_ = verbose;
    pro = processor_;
    //initialise
    instr = new int [64];
    for(int i = 0;i <= 63;i++) {
       instr[i] = 0;
    }
}
//Instruction Set Manual
string encoding::sets_instr() {
    string op, funct3, funct7, csr;

    for (int i=0;i<7;i++) {
       op.push_back(instr[i]+ '0');
       if(verbose_)
          cout<<"The op_num code of instruction["<<i<<"] = "<<instr[i]<<endl;
    }
    
    for (int i=12;i<15;i++) {
       funct3.push_back(instr[i]+ '0');
       if(verbose_)
          cout<<"The funct3_num code of instruction["<<i<<"] = "<<instr[i]<<endl;
    }

    for (int i=25;i<32;i++) {
       funct7.push_back(instr[i]+ '0');
       if(verbose_)
          cout<<"The funct7_num code of instruction["<<i<<"] = "<<instr[i]<<endl;
    }
    for (int i=20;i<32;i++)
    {
       csr.push_back(instr[i]+ '0');
    }
        
        //RV32I Base ins set
    if (op=="1110110") {
        return "LUI";   
    }
    if (op=="1110100") {
        return "AUIPC";
    }
    if (op=="1111011") {
        return "JAL";
    }
    if (op=="1110011"&&funct3=="000") {
        return "JALR";
    }
    if (op=="1100011"&&funct3=="000") {
        return "BEQ";
    }
    if (op=="1100011"&&funct3=="100") {
        return "BNE";
    }
    if (op=="1100011"&&funct3=="001") {
        return "BLT";
    }
    if (op=="1100011"&&funct3=="101") {
        return "BGE";
    }
    if (op=="1100011"&&funct3=="011") {
        return "BLTU";
    }
    if (op=="1100011"&&funct3=="111") {
        return "BGEU";
    }
    if (op=="1100000"&&funct3=="000") {
        return "LB";
    }
    if (op=="1100000"&&funct3=="100") {
        return "LH";
    }
    if (op=="1100000"&&funct3=="010") {
        return "LW";
    }
    if (op=="1100000"&&funct3=="001") {
        return "LBU";
    }
    if (op=="1100000"&&funct3=="101") {
        return "LHU";
    }
    if (op=="1100010"&&funct3=="000") {
        return "SB";
    }
    if (op=="1100010"&&funct3=="100") {
        return "SH";
    }
    if (op=="1100010"&&funct3=="010") {
        return "SW";
    }
    if (op=="1100100"&&funct3=="000") {
        return "ADDI";
    }
    if (op=="1100100"&&funct3=="010") {
        return "SLTI";
    }
    if (op=="1100100"&&funct3=="110") {
        return "SLTIU";
    }
    if (op=="1100100"&&funct3=="001") {
        return "XORI";
    }
    if (op=="1100100"&&funct3=="011") {
        return "ORI";
    }
    if (op=="1100100"&&funct3=="111") {
        return "ANDI";
    }
    if (op=="1100100"&&funct3=="100") {
        return "SLLI";
    }
    if (op=="1100100"&&funct3=="101"&&instr[30]==0) {
        return "SRLI";
    }
    if (op=="1100100"&&funct3=="101"&&instr[30]==1) {
        return "SRAI";
    }
    if (op=="1100110"&&funct3=="000"&&funct7=="0000000") {
        return "ADD";
    }
    if (op=="1100110"&&funct3=="000"&&funct7=="0000010") {
        return "SUB";
    }
    if (op=="1100110"&&funct3=="100"&&funct7=="0000000") {
        return "SLL";
    }
    if (op=="1100110"&&funct3=="010"&&funct7=="0000000") {
        return "SLT";
    }
    if (op=="1100110"&&funct3=="110"&&funct7=="0000000") {
        return "SLTU";
    }
    if (op=="1100110"&&funct3=="001"&&funct7=="0000000") {
        return "XOR";
    }
    if (op=="1100110"&&funct3=="101"&&funct7=="0000000") {
        return "SRL";
    }
    if (op=="1100110"&&funct3=="101"&&funct7=="0000010") {
        return "SRA";
    }
    if (op=="1100110"&&funct3=="011"&&funct7=="0000000") {
        return "OR";
    }
    if (op=="1100110"&&funct3=="111"&&funct7=="0000000") {
        return "AND";
    }
    
    //No operation 
    if (op=="1111000"&&funct3=="000") {
        return "FENCE";
    }
    if (op=="1111000"&&funct3=="100") {
        return "FENCE.I";
    }
    //UMIMPLEMENTED
    if (op=="1100111"&&funct3=="000"&&csr=="000000000000") {
        return "ECALL";
    }
    if (op=="1100111"&&funct3=="000"&&csr=="100000000000") {
        return "EBREAK";
    }
    
    if (op=="1100111"&&funct3=="100") {
        return "CSRRW";
    }
    if (op=="1100111"&&funct3=="010") {
        return "CSRRS";
    }
    if (op=="1100111"&&funct3=="110") {
        return "CSRRC";
    }
    if (op=="1100111"&&funct3=="101") {
        return "CSRRWI";
    }
    if (op=="1100111"&&funct3=="011") {
        return "CSRRSI";
    }
    if (op=="1100111"&&funct3=="111") {
        return "CSRRCI";
    }
    if (op=="1100111"&&csr=="010000001100") {
        return "MRET";
    }

    //RV64I Base ins set
    if (op=="1100000"&&funct3=="011") {
        return "LWU";
    }
    if (op=="1100000"&&funct3=="110") {
        return "LD";
    }
    if (op=="1100010"&&funct3=="110") {
        return "SD";
    }
    //if (op=="1100100"&&funct3=="100") return "SLLI";
    //if (op=="1100100"&&funct3=="101") return "SRLI";
    //if (op=="1100100"&&funct3=="101") return "SRAI";
    if (op=="1101100"&&funct3=="000") {
        return "ADDIW";
    }
    if (op=="1101100"&&funct3=="100"&&funct7=="0000000") {
        return "SLLIW";
    }
    if (op=="1101100"&&funct3=="101"&&instr[30]==0) {
        return "SRLIW";
    }
    if (op=="1101100"&&funct3=="101"&&instr[30]==1) {
        return "SRAIW";
    }
    if (op=="1101110"&&funct3=="000"&&funct7=="0000000") {
        return "ADDW";
    }
    if (op=="1101110"&&funct3=="000"&&funct7=="0000010") {
        return "SUBW";
    }
    if (op=="1101110"&&funct3=="100"&&funct7=="0000000") {
        return "SLLW";
    }
    if (op=="1101110"&&funct3=="101"&&funct7=="0000000") {
        return "SRLW";
    }
    if (op=="1101110"&&funct3=="101"&&funct7=="0000010") {
        return "SRAW";
    }
   
   return "Unreadable_command";
}

void encoding::computing(uint64_t memory_address) {
    load_address_(memory_address);
    string command=sets_instr();
    if( (pro->get_csr(0x344)&1) == 1)
    {
        //machine mode, not vectored
        if (pro->return_prv() == 3 && (pro->get_csr(0x305)&1) == 0)
        {
             //if mie = 1
            if (((pro->get_csr(0x300)&0x8)>>3) == 1)
            {  
                //mcause
                pro->set_csr(0x342,0x8000000000000000);
                machine_mode_interrupt();
            }    
        }
        //machine mode, vectored
        if (pro->return_prv() == 3 && (pro->get_csr(0x305)&1) == 1)
        {
            machine_mode_interrupt_vectored(0);
        }
        //User Mode
        if (pro->return_prv() == 0)
        {   
            if(((pro->get_csr(0x300)&0x8)>>3) == 1 || (pro->get_csr(0x304)&1) == 1)
                //mepc
                pro->set_csr(0x341,pro->get_pc());

            if(((pro->get_csr(0x300)&0x8)>>3) == 1)
                user_mode_interrupt(0);

            //usie   
            if((pro->get_csr(0x304)&1) == 1)
            {
                pro->set_csr(0x342,0x8000000000000000);
                user_mode_interrupt(1);
            }     
        }       
    }

    //Machine software interrupt (cause 3) in machine mode
    //mip.msip = 1
    if( ((pro->get_csr(0x344)&0x8)>>3) == 1)
    {
        //machine mode, not vectored
        if (pro->return_prv() == 3 && (pro->get_csr(0x305)&1) == 0)
        {
             //if mie = 1
            if (((pro->get_csr(0x300)&0x8)>>3) == 1)
            {  
                //mcause
                pro->set_csr(0x342,0x8000000000000003);
                machine_mode_interrupt();
            }    
        }
        //machine mode, vectored
        if (pro->return_prv() == 3 && (pro->get_csr(0x305)&1) == 1)
        {
            machine_mode_interrupt_vectored(3);
        }
        //User Mode
        if (pro->return_prv() == 0)
        {
            if(((pro->get_csr(0x304)&0x8)>>3) == 1)
                pro->set_csr(0x341,pro->get_pc());

            if(((pro->get_csr(0x300)&0x8)>>3) == 1)
                user_mode_interrupt(0);

            //msie
            if(((pro->get_csr(0x304)&0x8)>>3) == 1)
            {
                pro->set_csr(0x342,0x8000000000000003);
                user_mode_interrupt(1);
            }     
        }       
    }

    //User timer interrupt (cause 4) in machine mode
    //mip.utip = 1
    if( ((pro->get_csr(0x344)&0x10)>>4) == 1)
    {
        //machine mode, not vectored
        if (pro->return_prv() == 3 && (pro->get_csr(0x305)&1) == 0)
        {
             //if mie = 1
            if (((pro->get_csr(0x300)&0x8)>>3) == 1)
            {  
                //mcause
                pro->set_csr(0x342,0x8000000000000004);
                machine_mode_interrupt();
            }    
        }
        //machine mode, vectored
        if (pro->return_prv() == 3 && (pro->get_csr(0x305)&1) == 1)
        {
            machine_mode_interrupt_vectored(4);
        }
        //User Mode
        if (pro->return_prv() == 0)
        {    
            if(((pro->get_csr(0x304)&0x10)>>4) == 1)
            //mepc
            pro->set_csr(0x341,pro->get_pc());

            if(((pro->get_csr(0x300)&0x8)>>3) == 1)
                user_mode_interrupt(0);   
            if(((pro->get_csr(0x304)&0x10)>>4) == 1)
            {
                pro->set_csr(0x342,0x8000000000000004);
                user_mode_interrupt(1);
            }     
        }       
    }

    //Machine timer interrupt (cause 7) in machine mode
    if( ((pro->get_csr(0x344)&0x80)>>7) == 1)
    {
        //machine mode, not vectored
        if (pro->return_prv() == 3 && (pro->get_csr(0x305)&1) == 0)
        {
             //if mie = 1
            if (((pro->get_csr(0x300)&0x8)>>3) == 1)
            {  
                //mcause
                pro->set_csr(0x342,0x8000000000000007);
                machine_mode_interrupt();
            }    
        }
        //machine mode, vectored
        if (pro->return_prv() == 3 && (pro->get_csr(0x305)&1) == 1)
        {
            machine_mode_interrupt_vectored(7);
        }
        //User Mode
        if (pro->return_prv() == 0)
        {    
            if(((pro->get_csr(0x304)&0x80)>>7) == 1)
            //mepc
            pro->set_csr(0x341,pro->get_pc());

            if(((pro->get_csr(0x300)&0x8)>>3) == 1)
                user_mode_interrupt(0);   
            if(((pro->get_csr(0x304)&0x80)>>7) == 1)
            {
                pro->set_csr(0x342,0x8000000000000007);
                user_mode_interrupt(1);
            }     
        }       
    }

    //User external interrupt (cause 8) in machine mode
    if( ((pro->get_csr(0x344)&0x100)>>8) == 1)
    {
        //machine mode, not vectored
        if (pro->return_prv() == 3 && (pro->get_csr(0x305)&1) == 0)
        {
             //if mie = 1
            if (((pro->get_csr(0x300)&0x8)>>3) == 1)
            {  
                //mcause
                pro->set_csr(0x342,0x8000000000000008);
                machine_mode_interrupt();
            }    
        }
        //machine mode, vectored
        if (pro->return_prv() == 3 && (pro->get_csr(0x305)&1) == 1)
        {
            machine_mode_interrupt_vectored(8);
        }
        //User Mode
        if (pro->return_prv() == 0)
        {    
            if(((pro->get_csr(0x304)&0x100)>>8) == 1)
            //mepc
            pro->set_csr(0x341,pro->get_pc());

            if(((pro->get_csr(0x300)&0x8)>>3) == 1)
                user_mode_interrupt(0);   
            if(((pro->get_csr(0x304)&0x100)>>8) == 1)
            {
                pro->set_csr(0x342,0x8000000000000008);
                user_mode_interrupt(1);
            }     
        }       
    }

    //Machine external interrupt (cause 11) in machine mode
    if( ((pro->get_csr(0x344)&0x800)>>11) == 1)
    {
        //machine mode, not vectored
        if (pro->return_prv() == 3 && (pro->get_csr(0x305)&1) == 0){
             //if mie = 1
            if (((pro->get_csr(0x300)&0x8)>>3) == 1){  
                //mcause
                pro->set_csr(0x342,0x800000000000000B);
                machine_mode_interrupt();
            }    
        }
        //machine mode, vectored
        if (pro->return_prv() == 3 && (pro->get_csr(0x305)&1) == 1){
            machine_mode_interrupt_vectored(11);
        }
        //User Mode
        if (pro->return_prv() == 0){    
            if(((pro->get_csr(0x304)&0x800)>>11) == 1){
                pro->set_csr(0x341,pro->get_pc());
            }
            //mepc

            if(((pro->get_csr(0x300)&0x8)>>3) == 1)
                user_mode_interrupt(0);   
            if(((pro->get_csr(0x304)&0x800)>>11) == 1)
            {
                pro->set_csr(0x342,0x800000000000000B);
                user_mode_interrupt(1);
            }     
        }       
    }
    if (command=="Unreadable_command")
    {
        //cout<<"Illegal instruction: "<< setw(8) << setfill('0') << right << hex <<Main_Memory->read_doubleword(memory_address)<<endl;
        //exit(1);
        pro->set_csr(0x342,2);
        //mret(memory_address,0);
    }
    if (command=="LUI") {
        uint64_t imme = signed_bit_int32(12,31) << 12, rd = unsigned_bit_int32(7,11);
        if (instr[31]!=0) {
            imme |= 0xffffffff00000000;
        }
       pro->set_reg(rd, imme);
       if(verbose_)
            cout<<"lui: rd->"<<dec<<rd<<", immeed_U->"<<setfill('0')<<setw(16)<<hex<<imme<<endl; 
    }

    if (command=="ADDI") {
        uint64_t imme = signed_bit_int32(20,31), rd = unsigned_bit_int32(7,11), rs1 = pro->get_reg(unsigned_bit_int32(15,19));

        if(imme >>11 !=0) {
                imme |=  0xfffffffffffff000;
            }
        uint64_t out = imme + rs1;
        pro->set_reg(rd,out);
        if (verbose_)  
            cout<<"addi: rd->"<<dec<<rd<<", rs1->"<<dec<<unsigned_bit_int32(15,19)<<", immed->"<<setfill('0')<<setw(16)<<hex<<imme<<endl;
    }

    if (command=="ADDIW") {   
        uint64_t imme = signed_bit_int32(20,31), rd = unsigned_bit_int32(7,11), rs1 = pro->get_reg(unsigned_bit_int32(15,19));
        
        int32_t out = (rs1 + imme) & 0xffffffff;

        if (instr[31]!=0)
            pro->set_reg( rd , out | 0xffffffff00000000);
        pro->set_reg( rd , out );
     if (verbose_)
          cout<<"addiw: rd->"<<dec<<rd<<", rs1->"<<dec<<unsigned_bit_int32(15,19)<<", immed->"<<setfill('0')<<setw(16)<<hex<<imme<<endl;
    }
    
    if (command=="SLTI") {
        int64_t imme = signed_bit_int32(20,31), rs1 = pro->get_reg(unsigned_bit_int32(15,19));
        uint64_t rd = unsigned_bit_int32(7,11);

        if( (int64_t)rs1 < imme )
            pro->set_reg(rd,1);
        else
            pro->set_reg(rd,0);
        if(verbose_)
            cout<<"slti: rd->"<<dec<<rd<<", rs1->"<<dec<<unsigned_bit_int32(15,19)<<", immed->"<<setfill('0')<<setw(16)<<hex<<imme<<endl;
    }

    if (command=="SLTIU") {
        uint64_t imme = signed_bit_int32(20,31), rd = unsigned_bit_int32(7,11), rs1 = pro->get_reg(unsigned_bit_int32(15,19));

        if( rs1 < imme )
            pro->set_reg(rd,1);
        else
            pro->set_reg(rd,0);
        if(verbose_)
            cout<<"sltiu: rd->"<<dec<<rd<<", rs1->"<<dec<<unsigned_bit_int32(15,19)<<", immed->"<<setfill('0')<<setw(16)<<hex<<imme<<endl;
    }

    if (command=="XORI") {
       uint64_t imme = signed_bit_int32(20,31), rd = unsigned_bit_int32(7,11), rs1 = pro->get_reg(unsigned_bit_int32(15,19));
       
       pro->set_reg( rd , rs1 ^ imme);
       if(verbose_)
            cout<<"xori: rd->"<<dec<<rd<<", rs1->"<<dec<<unsigned_bit_int32(15,19)<<", immed->"<<setfill('0')<<setw(16)<<hex<<imme<<endl;
    }

    if (command=="ANDI") {
       uint64_t imme = signed_bit_int32(20,31), rd = unsigned_bit_int32(7,11), rs1 = pro->get_reg(unsigned_bit_int32(15,19));
       
       pro->set_reg( rd , rs1 & imme);
       if(verbose_)
            cout<<"andi: rd->"<<dec<<rd<<", rs1->"<<dec<<unsigned_bit_int32(15,19)<<", immed->"<<setfill('0')<<setw(16)<<hex<<imme<<endl;
    }

    if (command=="ORI") {
       uint64_t imme = signed_bit_int32(20,31), rd = unsigned_bit_int32(7,11), rs1 = pro->get_reg(unsigned_bit_int32(15,19));
       
       pro->set_reg( rd , rs1 | imme);
       if(verbose_)
            cout<<"ori: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", immed-> "<<setfill('0')<<setw(16)<<hex<<imme<<endl;
    }

    if (command=="SLLI") {
       uint64_t imme = signed_bit_int32(20,31), rd = unsigned_bit_int32(7,11), rs1 = pro->get_reg(unsigned_bit_int32(15,19));
       if(imme >>11 !=0) {
            imme = (imme | 0xfffffffffffff000);
        }
        imme &=0x3f;
       pro->set_reg( rd , rs1 << imme );
       if (verbose_)
            cout<<"slli: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", shamt-> "<<dec<<imme<<endl;
    }
    if (command=="SRLI") {
       uint64_t imme = signed_bit_int32(20,31), rd = unsigned_bit_int32(7,11), rs1 = pro->get_reg(unsigned_bit_int32(15,19));
       if(imme >>11 !=0) {
            imme = (imme | 0xfffffffffffff000);
        }
        imme &=0x3f;
       pro->set_reg( rd , rs1 >> imme );
       if (verbose_)
            cout<<"srli: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", shamt-> "<<dec<<imme<<endl;
    }
    if (command=="SRAI") {
      uint64_t imme = (signed_bit_int32(20,31) - 0x400), rd = unsigned_bit_int32(7,11), rs1= pro->get_reg(unsigned_bit_int32(15,19));

        if( imme >>11 !=0 ) {
                imme |=  0xfffffffffffff000;
            }
        imme &=0x3f;
       pro->set_reg( rd , (int64_t)rs1 >> imme  );
       if (verbose_)
            cout<<"srai: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", shamt-> "<<dec<<imme<<endl;
    }

    if (command=="SLLIW") {
       uint64_t imme = unsigned_bit_int32(20,24), rd = unsigned_bit_int32(7,11), rs1 = pro->get_reg(unsigned_bit_int32(15,19));
       uint64_t temp = (rs1 & 0xffffffff ) << imme;

       if((temp & 0xffffffff)>>31!=0)
            temp |= 0xffffffff00000000;
        else 
            temp &= 0xffffffff;
       pro->set_reg(rd , temp);
       if(verbose_)
            cout<<"slliw: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", shamt-> "<<setfill('0')<<setw(16)<<hex<<imme<<endl;
    }
    if (command=="SRLIW") {   
       uint64_t imme = unsigned_bit_int32(20,24), rd = unsigned_bit_int32(7,11), rs1 = pro->get_reg(unsigned_bit_int32(15,19));
       uint64_t temp = (rs1 & 0xffffffff ) >> imme;

       if((temp & 0xffffffff)>>31!=0)
            temp |= 0xffffffff00000000;
        else 
            temp &= 0xffffffff;
       pro->set_reg(rd , temp);
       if(verbose_)
            cout<<"srliw: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", shamt-> "<<setfill('0')<<setw(16)<<hex<<imme<<endl;
    }
    if (command=="SRAIW") {
        uint64_t imme = unsigned_bit_int32(20,24), rd = unsigned_bit_int32(7,11), rs1 = pro->get_reg(unsigned_bit_int32(15,19));
        uint64_t temp = ((int64_t)rs1 & 0xffffffff ) >> imme;

            if( ((int64_t)rs1 & 0xffffffff ) >> 31 != 0 ){
                uint64_t temp_mask = 0xffffffffffffffff << (32 - imme);
                temp |= temp_mask;
            }
            else
                temp = temp & 0xffffffff;

        pro->set_reg(rd, temp);
        if(verbose_)
            cout<<"sraiw: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", shamt-> "<<setfill('0')<<setw(16)<<hex<<imme<<endl;
    }

    if (command=="ADD") {
       uint64_t rs1= pro->get_reg(unsigned_bit_int32(15,19)), rs2= pro->get_reg(unsigned_bit_int32(20,24)), rd = unsigned_bit_int32(7,11);
       pro->set_reg(rd ,rs1 + rs2);
       if (verbose_)
            cout<<"add: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<endl;
    }
    if (command=="SUB") {
       uint64_t rs1= pro->get_reg(unsigned_bit_int32(15,19)), rs2= pro->get_reg(unsigned_bit_int32(20,24)), rd = unsigned_bit_int32(7,11);
       pro->set_reg(rd ,rs1 - rs2);
        if (verbose_)
            cout<<"sub: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<endl;
    }

    if (command=="ADDW") {
       uint64_t rs1= pro->get_reg(unsigned_bit_int32(15,19)), rs2= pro->get_reg(unsigned_bit_int32(20,24)), rd = unsigned_bit_int32(7,11);
       uint64_t out = rs1 + rs2;
       if((out & 0xffffffff)>>31!=0)
        out |= 0xffffffff00000000;
      else
        out &= 0xffffffff;
       pro->set_reg(rd ,out);
       if(verbose_)
          cout<<"addw: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<endl;
    }
    if (command=="SUBW") {
       uint64_t rs1= pro->get_reg(unsigned_bit_int32(15,19)), rs2= pro->get_reg(unsigned_bit_int32(20,24)), rd = unsigned_bit_int32(7,11);
       uint64_t out = rs1 - rs2;
       if((out & 0xffffffff)>>31!=0)
        out |= 0xffffffff00000000;
      else
        out &= 0xffffffff;
       pro->set_reg(rd ,out );
       if(verbose_)
          cout<<"subw: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<endl;
    }

    if (command=="SLT") {
       int64_t rs1= pro->get_reg(unsigned_bit_int32(15,19)), rs2= pro->get_reg(unsigned_bit_int32(20,24));
       uint64_t rd = unsigned_bit_int32(7,11);
       
       if ( rs1 < rs2 ) {
           pro->set_reg(rd,1);
       }
        else
           pro->set_reg(rd,0);
       if (verbose_)
             cout<<"slt: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<endl;
    }

    if (command=="SLTU") {
       uint64_t rs1= pro->get_reg(unsigned_bit_int32(15,19)), rs2= pro->get_reg(unsigned_bit_int32(20,24)), rd = unsigned_bit_int32(7,11);
       
       if ( rs1 < rs2 ) {
           pro->set_reg(rd,1);
       }
        else
           pro->set_reg(rd,0);
       if (verbose_)
             cout<<"sltu: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<endl;
    }
    if (command=="XOR") {
       uint64_t rs1= pro->get_reg(unsigned_bit_int32(15,19)), rs2= pro->get_reg(unsigned_bit_int32(20,24)), rd = unsigned_bit_int32(7,11);
       pro->set_reg(rd , rs1 ^ rs2 );
       if (verbose_)
            cout<<"xor: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<endl;
    }

    if (command=="OR") {
       uint64_t rs1= pro->get_reg(unsigned_bit_int32(15,19)), rs2= pro->get_reg(unsigned_bit_int32(20,24)), rd = unsigned_bit_int32(7,11);
       pro->set_reg(rd , rs1 | rs2 );
       if (verbose_)
            cout<<"or: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<endl;
    }
    if (command=="AND") {
       uint64_t rs1= pro->get_reg(unsigned_bit_int32(15,19)), rs2= pro->get_reg(unsigned_bit_int32(20,24)), rd = unsigned_bit_int32(7,11);
       pro->set_reg(rd , rs1 & rs2 );
       if (verbose_)
            cout<<"and: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<endl;
    }

    if (command=="SLL") {
       uint64_t rs1= pro->get_reg(unsigned_bit_int32(15,19)), rs2= pro->get_reg(unsigned_bit_int32(20,24)), rd = unsigned_bit_int32(7,11);
       uint64_t temp = rs2 & 0x3f;
        
       temp = rs1 << temp;
       pro->set_reg(rd ,temp);
       if (verbose_)
            cout<<"sll: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<endl;
    }

    if (command=="SRL") {
       uint64_t rs1= pro->get_reg(unsigned_bit_int32(15,19)), rs2= pro->get_reg(unsigned_bit_int32(20,24)), rd = unsigned_bit_int32(7,11);
       uint64_t temp = rs2 & 0x3f;
        
       temp = rs1 >> temp;
       pro->set_reg(rd ,temp);
       if (verbose_)
            cout<<"srl: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<endl;
    }
    if (command=="SRA") {
       int64_t rs1= pro->get_reg(unsigned_bit_int32(15,19)); 
       uint64_t rs2= pro->get_reg(unsigned_bit_int32(20,24)), rd = unsigned_bit_int32(7,11);
       uint64_t temp = rs2 & 0x3f;
        
       temp = rs1 >> temp;
       pro->set_reg(rd ,temp);
       if (verbose_)
            cout<<"sra: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<endl;
    }

    if (command=="SLLW") {
       uint64_t rs1= pro->get_reg(unsigned_bit_int32(15,19)), rs2= pro->get_reg(unsigned_bit_int32(20,24)), rd = unsigned_bit_int32(7,11);
       uint64_t temp = rs2 & 0x1f;
       temp = (rs1 & 0xffffffff) << temp;

       if((temp & 0xffffffff)>>31 != 0)
            temp |= 0xffffffff00000000;
        else 
            temp &= 0xffffffff;

       pro->set_reg(rd, temp);
       if(verbose_)
           cout<<"sllw: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<endl;
    }
    if (command=="SRLW") {
       uint64_t rs1= pro->get_reg(unsigned_bit_int32(15,19)), rs2= pro->get_reg(unsigned_bit_int32(20,24)), rd = unsigned_bit_int32(7,11);
       uint64_t temp = rs2 & 0x1f;

       temp = (rs1 & 0xffffffff) >> temp;
        if((temp & 0xffffffff)>> 31 != 0)
          temp |=  0xffffffff00000000;
        else 
          temp &= 0xffffffff;

       pro->set_reg(rd, temp);
       if(verbose_)
           cout<<"srlw: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<endl;
    }
    if (command=="SRAW") {
       uint64_t rs1= pro->get_reg(unsigned_bit_int32(15,19)), rs2= pro->get_reg(unsigned_bit_int32(20,24)), rd = unsigned_bit_int32(7,11);
       uint64_t temp = rs2 & 0x1f;

       uint64_t shamt = temp;
       uint64_t temp2 = (int64_t)rs1 & 0xffffffff;
       uint64_t sign = temp2 >>31;
       temp = temp2 >>shamt;

       if(sign!=0) {
          uint64_t value_mask = 0xffffffffffffffff << (32 - shamt);
          temp |= value_mask;
        }
        else {
          temp &= 0xffffffff;
        }

       pro->set_reg(rd, temp);
       if(verbose_)
          cout<<"sraw: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<endl;
    }

    if (command=="JAL") {  
        uint64_t imme10= unsigned_bit_int32(21,30) << 1, imme11= instr[20] << 11, imme19= unsigned_bit_int32(12,19) << 12, rd = unsigned_bit_int32(7,11); 
  
        uint64_t imme = imme19 | imme11 | imme10;
        if ( instr[31] != 0 )
            imme |= 0xfffffffffff00000;
        
       pro->set_reg(rd , pro->get_pc() + 4 );
       pro->set_pc(pro->get_pc() + imme - 4);
       if(verbose_)
         cout<<"jal: rd->"<<dec<<rd<<", immeed-> "<<setfill('0')<<setw(16)<<hex<<imme<<endl;   
    }
    if (command=="JALR") {
        int64_t imme = signed_bit_int32(20,31);
        uint64_t rs1 = pro->get_reg(unsigned_bit_int32(15,19)), rd = unsigned_bit_int32(7,11);
        if(instr[31]!=0)
        {
            imme |= 0xfffffffffffff000;
        }
        pro->set_reg(rd ,pro->get_pc() + 4 );
        pro->set_pc( (( rs1 + imme ) & 0xfffffffffffffffe) - 4 );
        if(verbose_)
            cout<<"jalr: rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rd-> "<<dec<<rd<<", immed-> "<<setfill('0')<<setw(16)<<hex<<imme<<endl;
        
    }

    if (command=="AUIPC") {  
        uint64_t imme = signed_bit_int32(12,31) << 12, rd = unsigned_bit_int32(7,11);
        if(instr[31] != 0) {
            imme |= 0xffffffff00000000;
        }
        pro->set_reg(rd, imme + pro->get_pc());
        if (verbose_)
            cout<<"auipc: rd-> "<<dec<<rd<<", immeed-> "<<setfill('0')<<setw(16)<<hex<<imme<<endl;  
    }
    
    if (command=="BEQ") { 
        uint64_t rs1 = pro->get_reg(unsigned_bit_int32(15,19)), rs2 = pro->get_reg(unsigned_bit_int32(20,24));
        uint64_t imme4_1 = unsigned_bit_int32(8,11) << 1, imme10_5 = unsigned_bit_int32(25,30) << 5, imme_11 = instr[7] << 11;
        uint64_t immeed_B = imme10_5 | imme4_1 | imme_11;
         if(instr[31]!=0) {
            immeed_B = (immeed_B | 0xfffffffffffff000);
        }
        if(rs1 == rs2) {
            pro->set_pc(pro->get_pc() + immeed_B -4 );
        }
        if(verbose_)
            cout<<"beq: rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<pro->get_reg(unsigned_bit_int32(20,24))<<", immeed-> "<<setfill('0')<<setw(16)<<hex<<immeed_B<<endl;
    }
    if (command=="BNE") {    
        
        uint64_t rs1 = pro->get_reg(unsigned_bit_int32(15,19)), rs2 = pro->get_reg(unsigned_bit_int32(20,24));
        uint64_t imme4_1 = unsigned_bit_int32(8,11) << 1, imme10_5 = unsigned_bit_int32(25,30) << 5, imme_11 = instr[7] << 11;
        uint64_t immeed_B = imme10_5 | imme4_1 | imme_11;
         if(instr[31]!=0) {
            immeed_B = (immeed_B | 0xfffffffffffff000);
        }
        if( rs1 != rs2) {  
            pro->set_pc(pro->get_pc() + immeed_B - 4 );
        }  
    }
    if (command=="BLT") {
        int64_t rs1 = pro->get_reg(unsigned_bit_int32(15,19)), rs2 = pro->get_reg(unsigned_bit_int32(20,24));
        uint64_t imme4_1 = unsigned_bit_int32(8,11) << 1, imme10_5 = unsigned_bit_int32(25,30) << 5, imme_11 = instr[7] << 11;
        uint64_t immeed_B = imme10_5 | imme4_1 | imme_11;
         if(instr[31]!=0) {
            immeed_B = (immeed_B | 0xfffffffffffff000);
        }
        if( rs1 < rs2) {
            pro->set_pc(pro->get_pc() + immeed_B -4 );
        }
        if(verbose_)
            cout<<"blt: rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<", immeed-> "<<setfill('0')<<setw(16)<<hex<<immeed_B<<endl;
    }
    if (command=="BGE") {
        int64_t rs1 = pro->get_reg(unsigned_bit_int32(15,19)), rs2 = pro->get_reg(unsigned_bit_int32(20,24));
        uint64_t imme4_1 = unsigned_bit_int32(8,11) << 1, imme10_5 = unsigned_bit_int32(25,30) << 5, imme_11 = instr[7] << 11;
        uint64_t immeed_B = imme10_5 | imme4_1 | imme_11;
         if(instr[31]!=0) {
            immeed_B = (immeed_B | 0xfffffffffffff000);
        }
        if( rs1 >= rs2) {
            pro->set_pc(pro->get_pc() + immeed_B -4 );
        }
         if(verbose_)
            cout<<"bge: rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<", immeed-> "<<setfill('0')<<setw(16)<<hex<<immeed_B<<endl;
    }
    if (command=="BLTU") {
        uint64_t rs1 = pro->get_reg(unsigned_bit_int32(15,19)), rs2 = pro->get_reg(unsigned_bit_int32(20,24));
        uint64_t imme4_1 = unsigned_bit_int32(8,11) << 1, imme10_5 = unsigned_bit_int32(25,30) << 5, imme_11 = instr[7] << 11;
        uint64_t immeed_B = imme10_5 | imme4_1 | imme_11;
         if(instr[31]!=0) {
            immeed_B = (immeed_B | 0xfffffffffffff000);
        }
        if( rs1 < rs2) {
            pro->set_pc(pro->get_pc() + immeed_B -4 );
        }
        if(verbose_)
            cout<<"bltu: rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<", immeed-> "<<setfill('0')<<setw(16)<<hex<<immeed_B<<endl;
    }
    if (command=="BGEU") {
        uint64_t rs1 = pro->get_reg(unsigned_bit_int32(15,19)), rs2 = pro->get_reg(unsigned_bit_int32(20,24));
        uint64_t imme4_1 = unsigned_bit_int32(8,11) << 1, imme10_5 = unsigned_bit_int32(25,30) << 5, imme_11 = instr[7] << 11;
        uint64_t immeed_B = imme10_5 | imme4_1 | imme_11;
         if(instr[31]!=0) {
            immeed_B = (immeed_B | 0xfffffffffffff000);
        }
        if( rs1 >= rs2) {
            pro->set_pc(pro->get_pc() + immeed_B -4 );
        }
        if(verbose_)
            cout<<"bgeu: rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<", immeed-> "<<setfill('0')<<setw(16)<<hex<<immeed_B<<endl;
    }
    if (command=="LB") {
        uint64_t imme = signed_bit_int32(20,31), rs1 = pro->get_reg(unsigned_bit_int32(15,19)), rd = unsigned_bit_int32(7,11);
        if(instr[31] != 0) {
            imme |= 0xfffffffffffff000;
        } 
        uint64_t address = imme + rs1;
        uint64_t data = memo->unaligned_addr(address) & 0xff;
        if (data>>7!=0)
            data |= 0xFFFFFFFFFFFFFF00;
        pro->set_reg(rd,data);
        if(verbose_)
            cout<<"lb: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", immed-> "<<setfill('0')<<setw(16)<<hex<<imme<<endl;
    }
    if (command=="LH") {
        uint64_t imme = signed_bit_int32(20,31), rs1 = pro->get_reg(unsigned_bit_int32(15,19)), rd = unsigned_bit_int32(7,11);
        if(instr[31] != 0) {
            imme |= 0xfffffffffffff000;
        } 
        uint64_t address = imme + rs1;
        uint64_t data = memo->unaligned_addr(address) & 0xffff;
        if (data>>15!=0)
            data |= 0xffffffffffff0000;
        
        if (address%2 != 0){
        }
        else
            pro->set_reg(rd,data);

        if(verbose_)
            cout<<"lh: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", immed-> "<<setfill('0')<<setw(16)<<hex<<imme<<endl;
    }
    if (command=="LW") {
        uint64_t imme = signed_bit_int32(20,31), rs1 = pro->get_reg(unsigned_bit_int32(15,19)), rd = unsigned_bit_int32(7,11);
        if(instr[31] != 0) {
            imme |= 0xfffffffffffff000;
        } 
        uint64_t address = imme + rs1;
        uint64_t data = memo->unaligned_addr(address) & 0xffffffff;
        if (data>>31==1)
            data |= 0xffffffff00000000;

        if (address%4 != 0){
        }
        else
            pro->set_reg(rd,data);

        if(verbose_) {
            cout<<"lw: rd->"<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", immed-> "<<setfill('0')<<setw(16)<<hex<<imme<<endl;
        }   
    }

    if (command=="LD") {
        uint64_t imme = signed_bit_int32(20,31), rs1 = pro->get_reg(unsigned_bit_int32(15,19)), rd = unsigned_bit_int32(7,11);
        if(instr[31] != 0) {
            imme |= 0xfffffffffffff000;
        } 
        uint64_t address = imme + rs1;
        uint64_t data = memo->read_doubleword(address); 
        if (address%8!=0){
        }
        else { 
            pro->set_reg(rd,data);
        }
            
        if (verbose_)
            cout<<"ld: rd->"<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", immed-> "<<setfill('0')<<setw(16)<<hex<<imme<<endl;
        
    }

    if (command=="LBU") {
        uint64_t imme = signed_bit_int32(20,31), rs1 = pro->get_reg(unsigned_bit_int32(15,19)), rd = unsigned_bit_int32(7,11);
        if(instr[31] != 0) {
            imme |= 0xfffffffffffff000;
        } 
        uint64_t address = imme + rs1;
        uint64_t data = memo->unaligned_addr(address) & 0xff;
        pro->set_reg(rd,data);
        if(verbose_) {
            cout<<"lbu: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", immed-> "<<setfill('0')<<setw(16)<<hex<<imme<<endl;
        }
    }
    if (command=="LHU") {
        uint64_t imme = signed_bit_int32(20,31), rs1 = pro->get_reg(unsigned_bit_int32(15,19)), rd = unsigned_bit_int32(7,11);
        if(instr[31] != 0) {
            imme |= 0xfffffffffffff000;
        } 
        uint64_t address = imme + rs1;
        uint64_t data = memo->unaligned_addr(address) & 0xffff;
        if (address%2 != 0){
        }
        else
            pro->set_reg(rd,data);

        if(verbose_) {
            cout<<"lhu: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", immed-> "<<setfill('0')<<setw(16)<<hex<<imme<<endl;
        }
    }

    if (command=="LWU") {
        uint64_t imme = signed_bit_int32(20,31), rs1 = pro->get_reg(unsigned_bit_int32(15,19)), rd = unsigned_bit_int32(7,11);
        if(instr[31] != 0) {
            imme |= 0xfffffffffffff000;
        } 
        uint64_t address = imme + rs1;
        uint64_t data = memo->unaligned_addr(address) & 0xFFFFFFFF;
        data &= 0xFFFFFFFF;
        if (address%4 != 0){
        }
        else
            pro->set_reg(rd,data);
        if(verbose_)
            cout<<"lwu: rd-> "<<dec<<rd<<", rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", immed-> "<<setfill('0')<<setw(16)<<hex<<imme<<endl;
    }
    
    if (command=="SB") {
        
        uint64_t rs1 = pro->get_reg(unsigned_bit_int32(15,19)), rs2 = pro->get_reg(unsigned_bit_int32(20,24))& 0xff;
        uint64_t imme4 = signed_bit_int32(7,11), imme11 = signed_bit_int32(25,31) << 5;
        uint64_t imme = imme4 | imme11;
         if(instr[31] != 0) {
            imme |= 0xfffffffffffff000;
        }
        uint64_t address = imme + rs1;
        int rem = address % 8 ;
        address = address - address % 8 ;
        rs2 = rs2 << rem*8;
        memo->write_doubleword(address,rs2, (0xff * pow(0x100,rem)) ); 
        if (verbose_) {
            cout<<"sb: rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<", immeed-> "<<setfill('0')<<setw(16)<<hex<<imme<<" rem : "<<dec<<rem<<endl;
        }   

    }
    if (command=="SH") {
        uint64_t rs1 = pro->get_reg(unsigned_bit_int32(15,19)), rs2 = pro->get_reg(unsigned_bit_int32(20,24)) & 0xffff;
        uint64_t imme4 = signed_bit_int32(7,11), imme11 = signed_bit_int32(25,31) << 5;
        uint64_t imme = imme4 | imme11;
         if(instr[31] != 0) {
            imme |= 0xfffffffffffff000;
        }
        uint64_t address = imme + rs1;
        int rem = address % 8 ;
        rs2 = rs2 << rem*8;

        if (address%2 != 0){
         }
        else {
            if ( rem < 7 )
                memo->write_doubleword(address,rs2, (0xffff * pow(0x100,rem)) );
            else {
                memo->write_doubleword(address, rs2 & ((8-rem)*0xff), 0xffffffffffffffff - rem * 0xff);
                memo->write_doubleword(address + 1 ,rs2 & ( 0xffff - (8-rem) * 0xff) >> (8*(8-rem) ) ,0x00000000000000ff);
            }
        }
        
         if (verbose_) {
            cout<<"sh: rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2-> "<<dec<<unsigned_bit_int32(20,24)<<", immeed_S-> "<<setfill('0')<<setw(16)<<hex<<imme<<" rem : "<<dec<<rem<<endl;
        }
    }

    if (command=="SW") {
        uint64_t rs1 = pro->get_reg(unsigned_bit_int32(15,19)), rs2 = pro->get_reg(unsigned_bit_int32(20,24)) & 0xffffffff;
        uint64_t imme4 = signed_bit_int32(7,11), imme11 = signed_bit_int32(25,31) << 5;
        uint64_t imme = imme4 | imme11;
         if(instr[31] != 0) {
            imme |= 0xfffffffffffff000;
        }
        uint64_t address = imme + rs1;
        int rem = address % 8 ;
        rs2 = rs2 << rem*8;

        if (address%4 != 0){
         }
        else {
             if ( rem < 5 )
                memo->write_doubleword(address,rs2, (0xffffffff * pow(0x100,rem)) );
             else {
                memo->write_doubleword(address, rs2 & ((8-rem)*0xff), 0xffffffffffffffff - rem * 0xff);
                memo->write_doubleword(address + 1 ,rs2 & ( 0xffffffff - (8-rem) * 0xff) >> (8*(8-rem) ) ,0x00000000000000ff);
            }
        }
       
         if (verbose_) {
            cout<<"sw: rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2->"<<dec<<unsigned_bit_int32(20,24)<<", immeed-> "<<setfill('0')<<setw(16)<<hex<<imme<<" rem : "<<dec<<rem<<endl;
        }
    }

    if (command=="SD") {
        uint64_t rs1 = pro->get_reg(unsigned_bit_int32(15,19)), rs2 = pro->get_reg(unsigned_bit_int32(20,24));
        uint64_t imme4 = signed_bit_int32(7,11), imme11 = signed_bit_int32(25,31) << 5 ;
        uint64_t imme = imme4 | imme11;
        if(instr[31] != 0) {
            imme |= 0xfffffffffffff000;
        }
        uint64_t address = imme + rs1;
        int rem = address % 8 ;
        if (rem != 0){
         }
        else {
            if (rem == 0)
                memo->def_addr(address,rs2);
            else {
                memo->write_doubleword(address, rs2 & ((8-rem)*0xff), 0xffffffffffffffff - rem * 0xff);
                memo->write_doubleword(address + 1 ,(rs2 & ( 0xffffffffffffffff - (8-rem) * 0xff)) >> (8*(8-rem) ) , 0xffffffffffffffff-(8-rem)*0xff00000000000000);
            }
        }   
        
        if(verbose_) {
            cout<<"sd: rs1-> "<<dec<<unsigned_bit_int32(15,19)<<", rs2->"<<dec<<unsigned_bit_int32(20,24)<<", immeed->"<<setfill('0')<<setw(16)<<hex<<imme<<endl;
        }
        
    }   
    if (command=="FENCE") {
    }
    if (command=="FENCE.I") {
    }

    if (command=="ECALL") {
        if (pro->return_prv() == 0)
        {
            //ecall from user mode
            pro->set_csr(0x342,8);

            //mepc set to current pc
            pro->set_csr(0x341,pro->get_pc());

            //pc set to mtvec
            pro->set_pc(pro->get_csr(0x305) - 4);

            pro->set_instruction_count(pro->get_instruction_count()-1); 
        }
        if(pro->return_prv() == 3)
        {

            //ecall from machine mode
            pro->set_csr(0x342,0xb);

            //mepc set to current pc
            pro->set_csr(0x341,pro->get_pc());

            //mstatus machine mode
            pro->set_csr(0x300, pro->get_csr(0x300) | 0x1800);

            //pc set to mtvec
            pro->set_pc(pro->get_csr(0x305) - 4);

            pro->set_instruction_count(pro->get_instruction_count()-1); 
        }
    }

    if (command=="EBREAK") {   
        //mpie = last mie
        if( (pro->get_csr(0x300)&0x8)>>3 == 1)
        {
            pro->set_csr(0x300,pro->get_csr(0x300)|0x80);
        }
        else
        {
            pro->set_csr(0x300,pro->get_csr(0x300)&0xFFFFFFFFFFFFFF7F);
        }
        //
        if(pro->return_prv()==3)
        {
            //mie
            //pro->set_csr(0x300,pro->get_csr(0x300) | 0x8);
            //mpp 
            pro->set_csr(0x300, pro->get_csr(0x300) | 0x1800);
            pro->set_csr(0x341, pro->get_pc());
        }
        if (pro->return_prv()==0)
        {
            //mie
            //pro->set_csr(0x300,pro->get_csr(0x300) & 0xFFFFFFFFFFFFFFF7);
            //mpp
            pro->set_csr(0x300, pro->get_csr(0x300) & 0xFFFFFFFFFFFFE7FF);
        }
            
       //Direct Mode
       //When MODE=Direct, all traps into machine mode cause the pc to be set to the address in the BASE field
        if( (pro->get_csr(0x305) & 0x1) == 0)
        {
            pro->set_pc((pro->get_csr(0x305) & 0xFFFFFFFFFFFFFFFC) - 4);
            pro->set_prv(3);
        }
                  
       //Vectored Mode
       //When MODE=Vectored, all synchronous exceptions into machine mode cause the pc to be set to the address in the BASE
       //field, whereas interrupts cause the pc to be set to the address in the BASE field plus four times the interrupt cause number.
        else
        {
            pro->set_pc((pro->get_csr(0x305) & 0xFFFFFFFFFFFFFFFC) + 4* (pro->get_csr(0x342)&8000000000000000) - 4);
            pro->set_prv(3);
        }
        
        //Machine Mode
       
        //mcause
        pro->set_csr(0x342,3);
        pro->set_instruction_count(pro->get_instruction_count()-1);
        pro->set_csr(0x300,pro->get_csr(0x300)&0xFFFFFFFFFFFFFFF7);
    }
    if (command=="MRET")
    {
        mret(memory_address,0);     
    }
    if (command=="CSRRW")
    {
        uint64_t csr = unsigned_bit_int32(20,31);
        if (pro->return_prv() == 0 || !pro->csr_is_defined(csr) || (pro->illegal_csr_write(csr)&&unsigned_bit_int32(15,19) != 0) )
        {
            mret(memory_address,2);
        }
        else
        {
            //If rd=x0, then the instruction shall not read the CSR
            if(unsigned_bit_int32(7,11) != 0)
            {
                pro->set_reg(unsigned_bit_int32(7,11),pro->get_csr(csr));  
            }
            if(csr!=0x344)
                pro->set_csr(csr,pro->get_reg(unsigned_bit_int32(15,19)));
            else
                pro->set_csr(csr,pro->get_reg(unsigned_bit_int32(15,19)&0x111));
        }   
    }
    if (command=="CSRRS")
    {
        uint64_t csr = unsigned_bit_int32(20,31);
        if (pro->return_prv() == 0 || !pro->csr_is_defined(csr) || (pro->illegal_csr_write(csr)&&unsigned_bit_int32(15,19) != 0) )
        {
            mret(memory_address,2);
        }
        else
        {
            pro->set_reg(unsigned_bit_int32(7,11),pro->get_csr(csr));
            if(unsigned_bit_int32(15,19) != 0 && csr!=0x344)
            {
                uint64_t mask = pro->get_reg(unsigned_bit_int32(15,19));
                pro->set_csr(csr,pro->get_csr(csr)|mask);
            }
            else if(unsigned_bit_int32(15,19) != 0 && csr==0x344)
            {
                uint64_t mask = pro->get_reg(unsigned_bit_int32(15,19));
                pro->set_csr(csr,(pro->get_csr(csr)|mask)&0x111);
            }
        }   
    }
    if (command=="CSRRC")
    {
        uint64_t csr = unsigned_bit_int32(20,31);
        if (pro->return_prv() == 0 || !pro->csr_is_defined(csr) || (pro->illegal_csr_write(csr)&&unsigned_bit_int32(15,19) != 0) )
        {
            mret(memory_address,2);
        }
        else
        {
            pro->set_reg(unsigned_bit_int32(7,11),pro->get_csr(csr));
            if(unsigned_bit_int32(15,19) != 0 && csr!=0x344)
            {
                uint64_t mask = pro->get_reg(unsigned_bit_int32(15,19));
                pro->set_csr(csr,pro->get_csr(csr)&(0xffffffffffffffff-mask));
            }
            else if(unsigned_bit_int32(15,19) != 0 && csr==0x344)
            {
                uint64_t mask = pro->get_reg(unsigned_bit_int32(15,19));
                pro->set_csr(csr,(pro->get_csr(csr)&(0xffffffffffffffff-mask))&0x111);
            }    
        }
          
    }
    if (command=="CSRRWI")
    {
        uint64_t csr = unsigned_bit_int32(20,31);
        if (pro->return_prv() == 0 || !pro->csr_is_defined(csr) || (pro->illegal_csr_write(csr)&&unsigned_bit_int32(15,19) != 0) )
        {
            mret(memory_address,2);
        }
        else
        {
            if(unsigned_bit_int32(7,11) != 0)
            {
                pro->set_reg(unsigned_bit_int32(7,11),pro->get_csr(csr));  
            }
            if(csr!=0x344)
                pro->set_csr(csr,unsigned_bit_int32(15,19));
            else
                pro->set_csr(csr,unsigned_bit_int32(15,19)&0x111);
        }
       
    }
    if (command=="CSRRSI")
    {
        uint64_t csr = unsigned_bit_int32(20,31);
        if (pro->return_prv() == 0 || !pro->csr_is_defined(csr) || (pro->illegal_csr_write(csr)&&unsigned_bit_int32(15,19) != 0) )
        {
            mret(memory_address,2);
        }
        else
        {
            if(unsigned_bit_int32(7,11) != 0)
            {
                pro->set_reg(unsigned_bit_int32(7,11),pro->get_csr(csr));  
            }
            uint64_t mask = unsigned_bit_int32(15,19);
            if(mask != 0 && csr!=0x344)
            {
                pro->set_csr(csr,pro->get_csr(csr)|mask);
            }
            else if(mask != 0 && csr==0x344)
            {
                pro->set_csr(csr,(pro->get_csr(csr)|mask)&0x111);
            }
        }     
    }
    if (command=="CSRRCI")
    {
        uint64_t csr = unsigned_bit_int32(20,31);
        if (pro->return_prv() == 0 || !pro->csr_is_defined(csr) || (pro->illegal_csr_write(csr)&&unsigned_bit_int32(15,19) != 0) )
        {
            mret(memory_address,2);
        }
        else
        {
            if(unsigned_bit_int32(7,11) != 0)
            {
                pro->set_reg(unsigned_bit_int32(7,11),pro->get_csr(csr));  
            }
            uint64_t mask = unsigned_bit_int32(15,19);
            if(mask != 0 && csr!=0x344)
            {
                pro->set_csr(csr,pro->get_csr(csr)&(0xffffffffffffffff-mask));
            }
            else if(mask != 0 && csr==0x344)
            {
                pro->set_csr(csr,(pro->get_csr(csr)&(0xffffffffffffffff-mask))&0x111);
            }
        } 
    }

}
uint32_t encoding::unsigned_bit_int32(int begin,int end) {
    int32_t out = 0;
    int32_t shift = 0;
    for (int i = begin;i <= end;i++) {
            if(instr[i] == 1)
                out += 1 << shift;
            shift++;
        }
    return out;
}
uint32_t encoding::signed_bit_int32(int begin,int end) {
    int32_t out=0;
    int32_t shift=0;   
    if(instr[end]==0) {
        for (int i = begin; i <= end-1; i++) {
            if(instr[i]==1)
                out += 1 << shift;
            shift++;
        }
        return out;
    }
    else {
        for (int i = begin; i <= end-1; i++) { 
            if(instr[i]==0)
                out += 1 << shift;
            shift++;
        }
        return ~out;
    }
    return 0;
}
void encoding::load_address_(uint64_t memory_address) {
    uint32_t data = memo->read_doubleword(memory_address) & 0xffffffff;
    int64_t i=0;
    for(int j=0; j<32; j++) {
       instr[j]=0;
    }
    while(data != 0) {
      instr[i++] = data % 2;
      data /= 2;
    }  
}
void encoding::mret(uint64_t memory_address, unsigned int Cause_code){
         if (Cause_code == 0 && pro->return_prv() == 3){
            //MIEis set to MPIE;
            if(((pro->get_csr(0x300)&0x80)>>7) == 1){
                pro->set_csr(0x300,pro->get_csr(0x300)|0x8);
            }
            else{
                pro->set_csr(0x300,pro->get_csr(0x300)&0xFFFFFFFFFFFFFFF7);
            }

            //the privilege mode is changed to y in MPP
            if(((pro->get_csr(0x300)&0x1800)>>11) == 3){
                pro->set_prv(3);
            }  
            else{
                pro->set_prv(0);
            }
            //MPIE is set to 1   
            pro->set_csr(0x300,pro->get_csr(0x300)|0x80);

            //MPP is set to U-Mode
            pro->set_csr(0x300,pro->get_csr(0x300)&0xFFFFFFFFFFFFE7FF);

            //mepc register is written with the virtual address of the instruction that took the trap
            
            pro->set_pc(pro->get_csr(0x341) - 4);
        }
        //Illegal instruction trap on mret in user mode
        else if(pro->return_prv() == 0){
            //An mret instruction executed in user mode. mcause 2
            pro->set_csr(0x342,2);

            //mepc set to current pc
            pro->set_csr(0x341,pro->get_pc());

            //mtval holds current instruction
            pro->set_csr(0x343,memo->read_doubleword(memory_address) & 0xffffffff);

            //pc set to mtvec
            pro->set_pc(pro->get_csr(0x305) - 4);

            pro->set_instruction_count(pro->get_instruction_count()-1);
        }
        else if (Cause_code == 2 && pro->return_prv() == 3){
            //MPP
            pro->set_csr(0x300,pro->get_csr(0x300)|0x1800);

            //MPIE
            pro->set_csr(0x300,pro->get_csr(0x300)&0xFFFFFFFFFFFFFF7F);

            //An mret instruction executed in user mode. mcause 2
            pro->set_csr(0x342,2);

            //mepc set to current pc
            pro->set_csr(0x341,pro->get_pc());

            //mtval holds current instruction
            pro->set_csr(0x343,memo->read_doubleword(memory_address) & 0xffffffff);

            //pc set to mtvec
            pro->set_pc(pro->get_csr(0x305) - 4);

            pro->set_instruction_count(pro->get_instruction_count()-1); 
        }
}

void encoding::misaligned_instr(){
    //mcause
    pro->set_csr(0x342,0);

    //mepc
    pro->set_csr(0x341,pro->get_pc());

    //mstatus MPP
    pro->set_csr(0x300,pro->get_csr(0x300)|0x1800);

    //mtval
    pro->set_csr(0x343,pro->get_pc());
    
    //pc
    pro->set_pc(pro->get_csr(0x305) - 4);

    pro->set_instruction_count(pro->get_instruction_count()-1);
}

void encoding::misaligned_load(uint64_t error_address){
    //mcause
    pro->set_csr(0x342,4);

    //mepc
    pro->set_csr(0x341,pro->get_pc());

    //mstatus MPP
    pro->set_csr(0x300,pro->get_csr(0x300)|0x1800);

    //mtval
    pro->set_csr(0x343,error_address);

    //pc
    pro->set_pc(pro->get_csr(0x305) - 4);

    pro->set_instruction_count(pro->get_instruction_count()-1);
}

void encoding::misaligned_store(uint64_t error_address){
    //mcause
    pro->set_csr(0x342,6);

    //mepc
    pro->set_csr(0x341,pro->get_pc());

    //mstatus MPP
    pro->set_csr(0x300,pro->get_csr(0x300)|0x1800);

    //mtval
    pro->set_csr(0x343,error_address);

    //pc
    pro->set_pc(pro->get_csr(0x305) - 4);

    pro->set_instruction_count(pro->get_instruction_count()-1);
}

//interrupt in machine mode
void encoding::machine_mode_interrupt(){
    //mie
    pro->set_csr(0x300,pro->get_csr(0x300)&0xFFFFFFFFFFFFFFF7);

    //mpie
    pro->set_csr(0x300,pro->get_csr(0x300)|0x80);

    //mpp
    pro->set_csr(0x300,pro->get_csr(0x300)|0x1800);

    //mepc
    pro->set_csr(0x341,pro->get_pc());

    //pc
    pro->set_pc(pro->get_csr(0x305));
}

void encoding::machine_mode_interrupt_vectored(int causecode){
    //mepc
    pro->set_csr(0x341,pro->get_pc());

    //mie
    pro->set_csr(0x300,pro->get_csr(0x300)&0xFFFFFFFFFFFFFFF7);

    //pc
    pro->set_pc((pro->get_csr(0x305)&0xFFFFFFFFFFFFFFFE)+ 4*causecode);

    //mpie
    pro->set_csr(0x300,pro->get_csr(0x300)|0x80);

    //mpp
    pro->set_csr(0x300,pro->get_csr(0x300)|0x1800);

    pro->set_csr(0x342,0x8000000000000000 + causecode);
}

void encoding::user_mode_interrupt(int mode){
    if ( mode == 0){
        //mie
        pro->set_csr(0x300,pro->get_csr(0x300)&0xFFFFFFFFFFFFFFF7);

        //mpie
        pro->set_csr(0x300,pro->get_csr(0x300)|0x80);

        //pc
        pro->set_pc(pro->get_csr(0x305));

        //pro->set_prv(0);
    }
    if (mode == 1){
        pro->set_prv(3);
        pro->set_pc(pro->get_csr(0x305));
    }
    
}
