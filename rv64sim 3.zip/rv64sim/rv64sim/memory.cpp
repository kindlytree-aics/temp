/* ****************************************************************
   RISC-V Instruction Set Simulator
   Computer Architecture, Semester 1, 2023

   Class members for memory

**************************************************************** */

#include <iostream>
#include <fstream>
#include <algorithm>
#include <iomanip>
#include <stdlib.h>
#include <cstdio>
#include <stdint.h>
#include <cmath>

#include "memory.h"
using namespace std;

// Constructor
memory::memory(bool verbose) {
  // TODO: ...
  verbose_ = verbose;
}

// Check if a page of store is allocated, and allocate if not
void memory::validate (uint64_t addr) {
  //TODO:...
  addr=addr-addr%8;
  uint64_t num = (addr-addr%(SIZEOFBLOCK/8))/(SIZEOFBLOCK/8);
  unsigned long long int *block=new unsigned long long int [SIZEOFBLOCK];
  
  page_pointer.push_back(block);
  data_in_block.push_back(num);
}

// Read a doubleword of data from a doubleword-aligned addr.
// If the addr is not a multiple of 8, it is rounded down to a multiple of 8.
uint64_t memory::read_doubleword (uint64_t addr) {
  // TODO: ...
  uint64_t def=0x0000000000000000ULL;
  uint64_t out=0x0000000000000000ULL;
  addr = addr - addr % 4; 
  uint64_t num = (addr-addr%(SIZEOFBLOCK/8))/(SIZEOFBLOCK/8);
  unsigned long long int location_ = find(data_in_block.begin(), data_in_block.end(), num) - data_in_block.begin();
  if(location_ < data_in_block.size()) {
    for(int j=0;j <= 63; j++) {
        if (*((page_pointer.at(location_) + 8*(addr%(SIZEOFBLOCK/8)))+j)  ==  1) {
          int64_t power=pow(2,j);
          out += power;
        }
      }
    return out;
  }
  validate(addr);
  return def;
}
// Write a doubleword of data to a doubleword-aligned addr.
// If the addr is not a multiple of 8, it is rounded down to a multiple of 8.
// The mask contains 1s for bytes to be updated and 0s for bytes that are to be unchanged.
void memory::write_doubleword (uint64_t addr, uint64_t data, uint64_t mask) {
  addr = addr - addr % 8 ;
  uint64_t num = (addr-addr%(SIZEOFBLOCK/8))/(SIZEOFBLOCK/8);
  unsigned long long int location_ = find(data_in_block.begin(), data_in_block.end(), num) - data_in_block.begin();

  if(location_ < data_in_block.size()) {
    int64_t i=0;
    int arr_data[64]={0};
    while(data != 0) {
      arr_data[i++] = data % 2;
      data /= 2;
    }

    int maskarray[64]={0};
    i=0;
    while(mask != 0) {
      maskarray[i++] = mask % 2;
      mask /= 2;
    }

   if(verbose_) {
          cout<<"Writing doubleword at addr:" <<&*(page_pointer.at(location_)+ 8*(addr%(SIZEOFBLOCK/8)))<<endl;
          cout<<"Data: ";
          for(int k=0;k<64;k++)
          {
          cout<<arr_data[k];
          }
          cout<<endl<<"Mask: ";
          for(int l=0;l<64;l++)
          {
           cout<<maskarray[l]<<endl;
          }
        }

  for(int j=0;j<64;j++) {
        if(verbose_)
            cout<<*((page_pointer.at(location_)+ 8*(addr%(SIZEOFBLOCK/8)))+j);
        if (maskarray[j]==1) {
          *((page_pointer.at(location_)+ 8*(addr%(SIZEOFBLOCK/8)))+j)= arr_data[j];
        }    
      }
        
  }
  else {
    validate(addr);
    write_doubleword(addr,data,mask);
  }
}
// Load a hex image file and provide the start addr for execution from the file in start_addr.
// Return true if the file was read without error, or false otherwise.
bool memory::load_file(string file_name, uint64_t &start_addr) {
  ifstream input_file(file_name);
  string input;
  unsigned int line_count = 0;
  unsigned int byte_count = 0;
  char record_start;
  char byte_string[3];
  char halfword_string[5];
  unsigned int record_length;
  unsigned int record_addr;
  unsigned int record_type;
  unsigned int record_data;
  unsigned int record_checksum;
  bool end_of_file_record = false;
  uint64_t load_addr;
  uint64_t load_data;
  uint64_t load_mask;
  uint64_t load_base_addr = 0x0000000000000000ULL;
  start_addr = 0x0000000000000000ULL;
  if (input_file.is_open()) {
    while (true) {
      line_count++;
      input_file >> record_start;
      if (record_start != ':') {
	cout << "Input line " << dec << line_count << " does not start with colon character" << endl;
	return false;
      }
      input_file.get(byte_string, 3);
      sscanf(byte_string, "%x", &record_length);
      input_file.get(halfword_string, 5);
      sscanf(halfword_string, "%x", &record_addr);
      input_file.get(byte_string, 3);
      sscanf(byte_string, "%x", &record_type);
      switch (record_type) {
      case 0x00:  // Data record
	for (unsigned int i = 0; i < record_length; i++) {
	  input_file.get(byte_string, 3);
	  sscanf(byte_string, "%x", &record_data);
	  load_addr = (load_base_addr | (uint64_t)(record_addr)) + i;
	  load_data = (uint64_t)(record_data) << ((load_addr % 8) * 8);
	  load_mask = 0x00000000000000ffULL << ((load_addr % 8) * 8);
	  write_doubleword(load_addr & 0xfffffffffffffff8ULL, load_data, load_mask);
	  byte_count++;
	}
	break;
      case 0x01:  // End of file
	end_of_file_record = true;
	break;
      case 0x02:  // Extended segment addr (set bits 19:4 of load base addr)
	load_base_addr = 0x0000000000000000ULL;
	for (unsigned int i = 0; i < record_length; i++) {
	  input_file.get(byte_string, 3);
	  sscanf(byte_string, "%x", &record_data);
	  load_base_addr = (load_base_addr << 8) | (record_data << 4);
	}
	break;
      case 0x03:  // Start segment addr (ignored)
	for (unsigned int i = 0; i < record_length; i++) {
	  input_file.get(byte_string, 3);
	  sscanf(byte_string, "%x", &record_data);
	}
	break;
      case 0x04:  // Extended linear addr (set upper halfword of load base addr)
	load_base_addr = 0x0000000000000000ULL;
	for (unsigned int i = 0; i < record_length; i++) {
	  input_file.get(byte_string, 3);
	  sscanf(byte_string, "%x", &record_data);
	  load_base_addr = (load_base_addr << 8) | (record_data << 16);
	}
	break;
      case 0x05:  // Start linear addr (set execution start addr)
	start_addr = 0x0000000000000000ULL;
	for (unsigned int i = 0; i < record_length; i++) {
	  input_file.get(byte_string, 3);
	  sscanf(byte_string, "%x", &record_data);
	  start_addr = (start_addr << 8) | record_data;
	}
	break;
      }
      input_file.get(byte_string, 3);
      sscanf(byte_string, "%x", &record_checksum);
      input_file.ignore();
      if (end_of_file_record)
	break;
    }
    input_file.close();
    cout << dec << byte_count << " bytes loaded, start addr = "
	 << setw(16) << setfill('0') << hex << start_addr << endl;
    return true;
  }
  else {
    cout << "Failed to open file" << endl;
    return false;
  }
}
void memory::show_address (uint64_t addr) {
  //cout << "0x" << setw(16) << setfill('0') << right << hex << read_doubleword(address) << endl;
  cout << setw(16) << setfill('0') << right << hex << read_doubleword(addr) << endl;
}
void memory::def_addr (uint64_t addr, uint64_t data) {
  write_doubleword(addr,data,0xFFFFFFFFFFFFFFFFULL);
}

uint64_t memory::unaligned_addr(uint64_t addr){
  uint64_t def=0x0000000000000000ULL;
  uint64_t out=0x0000000000000000ULL;
  uint64_t num = (addr-addr%(SIZEOFBLOCK/8))/(SIZEOFBLOCK/8);
  
  unsigned long long int location_ = find(data_in_block.begin(), data_in_block.end(), num) - data_in_block.begin();
  if(location_ < data_in_block.size()) {
    for(int i=0;i <= 63; i++) {
        if (*((page_pointer.at(location_) + 8*(addr%(SIZEOFBLOCK/8)))+i) == 1) {
          long long int power = pow(2,i);
          out += power;
        }
      }
    return out;
  }
  validate(addr);
  return def;
}

